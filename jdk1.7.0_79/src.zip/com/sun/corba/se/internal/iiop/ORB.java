/*
 * Copyright (c) 1995, 2003, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.corba.se.internal.iiop;

/**
 * Deprecated class for backward compatibility.
 */
public class ORB extends /* 1.4 value: com.sun.corba.se.internal.corba.ORB */
                           com.sun.corba.se.impl.orb.ORBImpl
{
    public ORB()
    {
        super();
    }
} // Class ORB
